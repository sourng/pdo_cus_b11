<div class="row">

<?php 
$sql_query="SELECT * FROM courses WHERE status=1";
$objCourse->getCourse($sql_query);

?>



</div>