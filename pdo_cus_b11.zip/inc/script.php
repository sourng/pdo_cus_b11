
    <!-- Bootstrap core CSS -->
    <link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">

    <!-- Custom styles for this template -->
    <link href="css/modern-business.css" rel="stylesheet">
    <script src="js/script.js"></script>


<style>
  h4{
    font-family:'Khmer CN Poipet';

  }
  h2{
    font-family:'Kh Kompong Chhnang(Teuk Phos)';    
   }
  .footer-color{
    color:white;
  }
hr {
height: 1px;
color: white;
background-color: white;
border: none;
}
</style>