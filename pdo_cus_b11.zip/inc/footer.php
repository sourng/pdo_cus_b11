 <footer class="py-5 bg-dark">
      <div class="container">
        <div class="row">
          <div class="col-md-4 footer-color"> Left footer side </div>
          <div class="col-md-4 footer-color"> Midle footer side </div>
          <div class="col-md-4 footer-color"> Right footer side </div>
        </div>

        <hr>
        
        <p class="m-0 text-center text-white">Copyright &copy; CUS 2018</p>
      </div>
      <!-- /.container -->
    </footer>