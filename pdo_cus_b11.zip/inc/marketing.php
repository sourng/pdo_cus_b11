<div class="row">

<?php 
  $sql_query="SELECT * FROM marketing";
  $objSlide->getMarketing($sql_query);

?>

  
  <!-- <div class="col-lg-4 mb-4">
    <div class="card h-100">
      <h4 class="card-header">ដាក់ពាក្យ​ចូល​រៀន​</h4>
      <div class="card-body">
        <p class="card-text">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Sapiente esse necessitatibus neque.</p>
      </div>
      <div class="card-footer">
        <a href="#" class="btn btn-primary">Learn More</a>
      </div>
    </div>
  </div>

  <div class="col-lg-4 mb-4">
    <div class="card h-100">
      <h4 class="card-header">បណ្តុះ​បណ្តាល​</h4>
      <div class="card-body">
        <p class="card-text">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Reiciendis ipsam eos, nam perspiciatis natus commodi similique totam consectetur praesentium molestiae atque exercitationem ut consequuntur, sed eveniet, magni nostrum sint fuga.</p>
      </div>
      <div class="card-footer">
        <a href="#" class="btn btn-primary">Learn More</a>
      </div>
    </div>
  </div>


  <div class="col-lg-4 mb-4">
    <div class="card h-100">
      <h4 class="card-header">ទទួល​ស្កាល់​</h4>
      <div class="card-body">
        <p class="card-text">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Sapiente esse necessitatibus neque.</p>
      </div>
      <div class="card-footer">
        <a href="#" class="btn btn-primary">Learn More</a>
      </div>
    </div>
  </div>
 -->


</div>