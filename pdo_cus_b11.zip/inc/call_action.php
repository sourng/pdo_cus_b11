<div class="row mb-4">
  <div class="col-md-8">
    <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Molestias, expedita, saepe, vero rerum deleniti beatae veniam harum neque nemo praesentium cum alias asperiores commodi.</p>
  </div>
  <div class="col-md-4">
    <a class="btn btn-lg btn-secondary btn-block" href="#">Call to Action</a>
  </div>
</div>

</div>